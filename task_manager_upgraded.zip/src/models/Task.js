import mongoose from "mongoose";

const taskSchema = new mongoose.Schema({
  text: String,
  done: { type: Boolean, default: false },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
});

export default mongoose.model("Task", taskSchema);
