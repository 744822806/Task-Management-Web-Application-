import express from "express";
import Task from "../models/Task.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const task = await Task.create({
    text: req.body.text,
    owner: req.userId
  });
  res.json(task);
});

router.get("/", async (req, res) => {
  const tasks = await Task.find({ owner: req.userId });
  res.json(tasks);
});

router.put("/:id", async (req, res) => {
  const task = await Task.findOneAndUpdate(
    { _id: req.params.id, owner: req.userId },
    req.body,
    { new: true }
  );
  res.json(task);
});

router.delete("/:id", async (req, res) => {
  await Task.deleteOne({ _id: req.params.id, owner: req.userId });
  res.json({ ok: true });
});

export default router;
