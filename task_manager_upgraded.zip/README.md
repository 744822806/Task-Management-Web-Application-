# Upgraded Task Manager (JWT + CRUD)

This project extends a basic todo app by adding:
- User registration & login with JWT
- Per-user task ownership
- Secure Express backend
- MongoDB storage
- Simple HTML/JS frontend

## Setup
1. Install dependencies:
```
npm install
```

2. Edit MongoDB connection:
`src/app.js` → replace `YOUR_MONGO_URI`

3. Run the backend:
```
node src/app.js
```

Frontend auto-loads from `/public`.

