let token = null;

async function register() {
  const username = document.getElementById("reg_user").value;
  const email = document.getElementById("reg_email").value;
  const password = document.getElementById("reg_pass").value;

  await fetch("/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password }),
  });

  alert("Registered!");
}

async function login() {
  const email = document.getElementById("log_email").value;
  const password = document.getElementById("log_pass").value;

  const res = await fetch("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  token = data.token;
  loadTasks();
}

async function loadTasks() {
  const res = await fetch("/tasks", {
    headers: { Authorization: "Bearer " + token },
  });

  const tasks = await res.json();
  const list = document.getElementById("task_list");
  list.innerHTML = "";

  tasks.forEach(t => {
    const li = document.createElement("li");
    li.textContent = t.text;
    li.onclick = () => deleteTask(t._id);
    list.appendChild(li);
  });
}

async function addTask() {
  const text = document.getElementById("task_input").value;

  await fetch("/tasks", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token,
    },
    body: JSON.stringify({ text }),
  });

  loadTasks();
}

async function deleteTask(id) {
  await fetch("/tasks/" + id, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token },
  });

  loadTasks();
}
